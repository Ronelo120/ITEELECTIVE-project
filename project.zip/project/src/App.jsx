import './App.css';
import Products from './Products'; 

const App = () => {
  return (
    <div>
      <Products />
    </div>
  );
};

export default App;
