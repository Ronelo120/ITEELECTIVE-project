import { useState, useEffect } from "react";
import "./Products.css";
import cartLogo from "./image/Shopping_icon.png";

const Shop = () => {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [cart, setCart] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("https://67f0ca8a2a80b06b8898a6b1.mockapi.io/v1/products");
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    document.body.classList.toggle("cart-open", isCartOpen);
  }, [isCartOpen]);

  const addToCart = (product) => {
    const existingProductIndex = cart.findIndex((item) => item.id === product.id);
    
    if (existingProductIndex !== -1) {
      const updatedCart = [...cart];
      updatedCart[existingProductIndex].quantity += 1;
      setCart(updatedCart);
    } else {
      setCart((prevCart) => [...prevCart, { ...product, quantity: 1 }]);
    }
  };

  const removeFromCart = (productId) => {
    const updatedCart = cart.filter((item) => item.id !== productId);
    setCart(updatedCart);
  };

  const updateQuantity = (productId, quantity) => {
    const updatedQuantity = Math.max(1, Number(quantity));
    const updatedCart = cart.map((item) =>
      item.id === productId ? { ...item, quantity: updatedQuantity } : item
    );
    setCart(updatedCart);
  };

  const openModal = (product) => setSelectedProduct(product);
  const closeModal = () => setSelectedProduct(null);
  const toggleCart = () => setIsCartOpen(!isCartOpen);

  return (
    <div>
      <h2>Products</h2>

      <div class="header">
        <div className="logo-container">
          <img
            src={cartLogo}
            alt="Cart"
            className="logo"
            onClick={toggleCart}
          />
          {cart.length > 0 && <span className="badge">{cart.length}</span>}
        </div>
      </div>  

      <div className="product-list">
        {products.map((product) => (
          <div key={product.id} className="product-card">
            <img
              src={product.image}
              alt={product.name}
              onClick={() => openModal(product)}
            />
            <h3>{product.name}</h3>
            <p>₱{product.price.toFixed(2)}</p>
            <button onClick={() => addToCart(product)}>Add to Cart</button>
          </div>
        ))}
      </div>

      {selectedProduct && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <span className="close-button" onClick={closeModal}>
              &times;
            </span>
            <img
              src={selectedProduct.image}
              alt={selectedProduct.name}
              className="modal-image"
            />
            <h2>{selectedProduct.name}</h2>
            <p><strong>Description:</strong> {selectedProduct.description}</p>
            <p><strong>Price:</strong> ₱{selectedProduct.price.toFixed(2)}</p>
            <button onClick={() => addToCart(selectedProduct)}>Add to Cart</button>
          </div>
        </div>
      )}

      <div className={`cart-sidebar ${isCartOpen ? "open" : ""}`}>
        <span className="close-button" onClick={toggleCart}>
          &times;
        </span>

        <h2>Your Cart</h2>
        {cart.length === 0 ? (
          <p>Your cart is empty.</p>
        ) : (
          <ul>
            {cart.map((item) => (
              <li key={item.id}>
                <div className="cart-item">
                  <img src={item.image} alt={item.name} className="cart-item-image" />
                  <div className="cart-item-details">
                    <span>{item.name} - ₱{item.price.toFixed(2)}</span>
                    <div>
                      <button onClick={() => updateQuantity(item.id, item.quantity - 1)}>-</button>
                      <span> Quantity: {item.quantity} </span>
                      <button onClick={() => updateQuantity(item.id, item.quantity + 1)}>+</button>
                    </div>
                    <button onClick={() => removeFromCart(item.id)}>Remove</button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default Shop;
